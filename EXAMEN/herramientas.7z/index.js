console.log("holita");
console.log(11111);
function salida(){
            console.log('hola');
}
function sumar(a,b){
            console.log(a+b*2);
}
var restar= function(a,b){return a-b;}
        